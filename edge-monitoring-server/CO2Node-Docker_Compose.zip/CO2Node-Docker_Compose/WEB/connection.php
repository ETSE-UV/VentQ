<?php
    function connect(){
        $host="datab";
        $user="root";
        $pass="n0d3mcu";
        $BD="nmcu";
        $mysqli = new mysqli($host, $user, $pass, $BD);
        if ($mysqli->connect_errno) {
            echo "Falló la conexión a MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
        }
        else{
            return $mysqli;
        }
    }
    function disconnect($mysqli){
        mysqli_close($mysqli);
    }
    
    function getx($x){
        $conn=connect();
        $stmt = $conn->prepare("SELECT * FROM nmcu.measures_co2 WHERE id=? ORDER BY id DESC LIMIT 0,1;");
        $stmt->bind_param("i", $x);
        $stmt->execute();
        $result = $stmt->get_result();
        while($data = $result->fetch_assoc()){
           $ret[]=$data;
        }
        disconnect($conn);
        return json_encode($ret);
    }
    
    function getlastx($x){
        $conn=connect();
        $stmt = $conn->prepare("SELECT * FROM nmcu.measures_co2 ORDER BY id DESC LIMIT 0,?;");
        $stmt->bind_param("i", $x);
        $stmt->execute();
        $result = $stmt->get_result();
        while($data = $result->fetch_assoc()){
           $ret[]=$data;
        }
        disconnect($conn);
        return json_encode($ret);
    }
    
    function putco2measure($m){
        $conn=connect();
        $stmt = $conn->prepare("SELECT id FROM nmcu.nodes WHERE mac=?;");
        $stmt->bind_param("s", $m['mac']);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();
        $m['id_node']=$data['id'];
        $stmt = $conn->prepare("INSERT INTO nmcu.measures_co2 (id_node, date, co2, temperature, humidity) VALUES (?, NOW(), ?, ?, ?);");
        $stmt->bind_param("isss", $m['id_node'], $m['co2'], $m['temperature'], $m['humidity']);
        $stmt->execute();
        $result = $stmt->get_result();
        disconnect($conn);
        return $result;
    }
    
    function getlastnx($n,$x){
        $conn=connect();
        $stmt = $conn->prepare("SELECT * FROM nodes WHERE name=?;");
        $stmt->bind_param("s", $n);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();
        $id_node=$data['id'];
        $stmt = $conn->prepare("SELECT * FROM nmcu.measures_co2 WHERE id_node=? ORDER BY id DESC LIMIT 0,?;");
        $stmt->bind_param("ii", $id_node, $x);
        $stmt->execute();
        $result = $stmt->get_result();
        while($data = $result->fetch_assoc()){
           $ret[]=$data;
        }
        disconnect($conn);
        return json_encode($ret);
    }
    
    function getnodes(){
        $conn=connect();
        $stmt = $conn->prepare("SELECT * FROM nmcu.nodes ORDER BY id ASC;");
        $stmt->execute();
        $result = $stmt->get_result();
        while($data = $result->fetch_assoc()){
           $ret[]=$data;
        }
        disconnect($conn);
        return json_encode($ret);
    }
    
    function getnoden($n){
        $conn=connect();
        $stmt = $conn->prepare("SELECT * FROM nmcu.nodes WHERE name=?;");
        $stmt->bind_param("s", $n);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();
        $id_node=$data['id'];
        $ret['id']=$data['id'];
        $ret['name']=$data['name'];
        $ret['mac']=$data['mac'];
        $ret['location']=$data['location'];
        $stmt = $conn->prepare("SELECT b.name as board
                               FROM nmcu.nodes_boards AS nb
                               JOIN nmcu.boards AS b ON(b.id=nb.id_board)
                               WHERE nb.id_node=?
                               ;");
        $stmt->bind_param("i", $id_node);
        $stmt->execute();
        $result = $stmt->get_result();
        while($data = $result->fetch_assoc()){
           $ret['boards'][]=$data;
        }
        $stmt = $conn->prepare("SELECT s.type, s.model
                               FROM nmcu.nodes_sensors AS ns
                               JOIN nmcu.sensors AS s ON(s.id=ns.id_sensor)
                               WHERE ns.id_node=?
                               ;");
        $stmt->bind_param("i", $id_node);
        $stmt->execute();
        $result = $stmt->get_result();
        while($data = $result->fetch_assoc()){
           $ret['sensors'][]=$data;
        }
        $stmt = $conn->prepare("SELECT a.type, a.model
                               FROM nmcu.nodes_actuators AS na
                               JOIN nmcu.actuators AS a ON(a.id=na.id_actuator)
                               WHERE na.id_node=?
                               ;");
        $stmt->bind_param("i", $id_node);
        $stmt->execute();
        $result = $stmt->get_result();
        while($data = $result->fetch_assoc()){
           $ret['actuators'][]=$data;
        }
        disconnect($conn);
        return json_encode($ret);
    }
                               
   function getfirmware($m){
       $conn=connect();
       $query="SELECT f.file FROM nmcu.firmwares as f JOIN nmcu.nodes_firmware as nf ON(nf.id_firmware=f.id) JOIN nmcu.nodes as n ON(n.id=nf.id_node) WHERE n.mac=? ORDER BY f.id DESC LIMIT 0,1;";
       $stmt = $conn->prepare($query);
       $stmt->bind_param("s", $m);
       $stmt->execute();
       $result = $stmt->get_result();
       $data = $result->fetch_assoc();
       $file=$data['file'];
       
       disconnect($conn);
       return $file;
   }

    
    
?>
