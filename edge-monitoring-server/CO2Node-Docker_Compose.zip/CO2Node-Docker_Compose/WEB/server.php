<?php
    
    include ("connection.php");
    include ("firmware.php");
    class Server {
        private $contacts = array('jim' => array('address' => '356 Trailer Park Avenue', 'url' => '/clients/jim'),
                                  'anne' => array('address' => '6321 Tycoon Road', 'url'=> '/clients/anne')
    );
        private $co2_data = array('1' => array('node' => 'Node1', 'date' => '2020-12-10 10:00:00', 'co2' => '310', 'temperature' => '21.5', 'humidity' => '41'),
                                  '2' => array('node' => 'Node2', 'date' => '2020-12-10 10:00:05', 'co2' => '320', 'temperature' => '22.5', 'humidity' => '42'),
                                  '3' => array('node' => 'Node3', 'date' => '2020-12-10 10:00:10', 'co2' => '330', 'temperature' => '23.5', 'humidity' => '43'),
                                  '4' => array('node' => 'Node1', 'date' => '2020-12-10 10:00:15', 'co2' => '340', 'temperature' => '24.5', 'humidity' => '44'),
                                  '5' => array('node' => 'Node3', 'date' => '2020-12-10 10:00:20', 'co2' => '350', 'temperature' => '25.5', 'humidity' => '45'),
                                  '6' => array('node' => 'Node4', 'date' => '2020-12-10 10:00:25', 'co2' => '360', 'temperature' => '26.5', 'humidity' => '46'),
                                  '7' => array('node' => 'Node1', 'date' => '2020-12-10 10:00:30', 'co2' => '370', 'temperature' => '27.5', 'humidity' => '47'),
                                  '8' => array('node' => 'Node2', 'date' => '2020-12-10 10:00:35', 'co2' => '380', 'temperature' => '28.5', 'humidity' => '48'),
                                  '9' => array('node' => 'Node3', 'date' => '2020-12-10 10:00:40', 'co2' => '390', 'temperature' => '29.5', 'humidity' => '49'),
                                  '10' => array('node' => 'Node1', 'date' => '2020-12-10 10:00:45', 'co2' => '310', 'temperature' => '30.5', 'humidity' => '50'),
                                  '11' => array('node' => 'Node2', 'date' => '2020-12-10 10:00:50', 'co2' => '311', 'temperature' => '31.5', 'humidity' => '51'),
                                  '12' => array('node' => 'Node3', 'date' => '2020-12-10 10:00:55', 'co2' => '312', 'temperature' => '32.5', 'humidity' => '52'),
                                  '13' => array('node' => 'Node1', 'date' => '2020-12-10 10:00:60', 'co2' => '313', 'temperature' => '33.5', 'humidity' => '53'),
                                  '14' => array('node' => 'Node2', 'date' => '2020-12-10 10:00:65', 'co2' => '314', 'temperature' => '34.5', 'humidity' => '54'),
    );

    public function serve() {
      
        $uri = $_SERVER['REQUEST_URI'];
        $method = $_SERVER['REQUEST_METHOD'];
        $paths = explode('/', $this->paths($uri));
        array_shift($paths);
        $resource = array_shift($paths);
        error_log($resource);
      
        if ($resource == 'clients') {
            $name = array_shift($paths);
	
            if (empty($name)) {
                $this->handle_base($method);
            } else {
                $this->handle_name($method, $name);
            }
          
            
        }
        elseif ($resource == 'co2_measures') {
            $x = array_shift($paths);
    
            if (empty($x)) {
                $this->lastx($method, 10);
            } else {
                $this->lastx($method, $x);
            }
        }
        elseif ($resource == 'co2_measure') {
            $x = array_shift($paths);
            error_log("co2_measure");
    
            if (empty($x)) {
                $this->lastx($method, 1);
            } else {
                $this->mesx($method, $x);
            }
        }
        elseif ($resource == 'node') {
            $n = array_shift($paths);
            $x = array_shift($paths);
    
            if (empty($n)) {
                header('HTTP/1.1 404 Not Found');
            }
            elseif (empty($x)) {
                $this->lastnx($method, $n, 10);
            }
            else {
                $this->lastnx($method, $n, $x);
            }
        }
        elseif ($resource == 'nodes') {
            $x = array_shift($paths);
    
            if (empty($x)) {
                $this->nodes($method);
            }
            else {
                $this->nodex($method, $x);
            }
        }
        elseif ($resource == 'firmware') {
            firmware();
        }
        else {
            // We only handle resources under 'clients'
            header('HTTP/1.1 404 Not Found');
        } 
    }
    
    private function lastx($method, $x) {
        switch($method) {
        case 'GET':
            header('Content-type: application/json');
            echo getlastx($x);
            break;
        case 'PUT':
            $data = json_decode(file_get_contents('php://input'),true);
            
            if (is_null($data)) {
                header('HTTP/1.1 400 Bad Request');
                return;
            }
            else{
                header('Content-type: application/json');
                putco2measure($data);
            }
            
            break;
        default:
            header('HTTP/1.1 405 Method Not Allowed');
            header('Allow: GET, PUT');
            break;
        }
    }
        
    private function mesx($method, $x) {
        switch($method) {
        case 'GET':
            header('Content-type: application/json');
            echo getx($x);
            break;
        default:
            header('HTTP/1.1 405 Method Not Allowed');
            header('Allow: GET, PUT');
            break;
        }
    }
    
    private function lastnx($method, $n, $x) {
        switch($method) {
        case 'GET':
            header('Content-type: application/json');
            echo getlastnx($n,$x);
            break;
        default:
            header('HTTP/1.1 405 Method Not Allowed');
            header('Allow: GET');
            break;
        }
    }
        
    private function nodes($method) {
        switch($method) {
        case 'GET':
            header('Content-type: application/json');
            echo getnodes();
            break;
        default:
            header('HTTP/1.1 405 Method Not Allowed');
            header('Allow: GET');
            break;
        }
    }
        
    private function nodex($method, $n) {
        switch($method) {
        case 'GET':
            header('Content-type: application/json');
            echo getnoden($n);
            break;
        default:
            header('HTTP/1.1 405 Method Not Allowed');
            header('Allow: GET');
            break;
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
        
    private function handle_base($method) {
        switch($method) {
        case 'GET':
            $this->result();
            break;
        default:
            header('HTTP/1.1 405 Method Not Allowed');
            header('Allow: GET');
            break;
        }
    }

    private function handle_name($method, $name) {
        switch($method) {
        case 'PUT':
            $this->create_contact($name);
            break;

        case 'DELETE':
            $this->delete_contact($name);
            break;
      
        case 'GET':
            $this->display_contact($name);
            break;

        default:
            header('HTTP/1.1 405 Method Not Allowed');
            header('Allow: GET, PUT, DELETE');
            break;
        }
    }

    private function create_contact($name){
        if (isset($this->contacts[$name])) {
            header('HTTP/1.1 409 Conflict');
            return;
        }
        /* PUT requests need to be handled
         * by reading from standard input.
         */
        $data = json_decode(file_get_contents('php://input'));
        if (is_null($data)) {
            header('HTTP/1.1 400 Bad Request');
            $this->result();
            return;
        }
        $this->contacts[$name] = $data; 
        $this->result();
    }
    
    private function delete_contact($name) {
        if (isset($this->contacts[$name])) {
            unset($this->contacts[$name]);
            $this->result();
        } else {
            header('HTTP/1.1 404 Not Found');
        }
    }
    
    private function display_contact($name) {
        if (array_key_exists($name, $this->contacts)) {
            echo json_encode($this->contacts[$name]);
        } else {
            header('HTTP/1.1 404 Not Found');
        }
    }
    
    private function paths($url) {
        $uri = parse_url($url);
        return $uri['path'];
    }
    
    /**
     * Displays a list of all contacts.
     */
    private function result() {
        header('Content-type: application/json');
        echo json_encode($this->contacts);
    }
  }

$server = new Server;
$server->serve();

?>

