-- Grants dumped by pt-show-grants
-- Dumped from server Localhost via UNIX socket, MySQL 5.7.33 at 2021-02-18 21:13:47
-- Grants for 'mysql.session'@'localhost'
CREATE USER IF NOT EXISTS 'mysql.session'@'localhost';
ALTER USER 'mysql.session'@'localhost' IDENTIFIED WITH 'mysql_native_password' AS '*THISISNOTAVALIDPASSWORDTHATCANBEUSEDHERE' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT LOCK;
GRANT SELECT ON `mysql`.`user` TO 'mysql.session'@'localhost';
GRANT SELECT ON `performance_schema`.* TO 'mysql.session'@'localhost';
GRANT SUPER ON *.* TO 'mysql.session'@'localhost';
-- Grants for 'mysql.sys'@'localhost'
CREATE USER IF NOT EXISTS 'mysql.sys'@'localhost';
ALTER USER 'mysql.sys'@'localhost' IDENTIFIED WITH 'mysql_native_password' AS '*THISISNOTAVALIDPASSWORDTHATCANBEUSEDHERE' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT LOCK;
GRANT SELECT ON `sys`.`sys_config` TO 'mysql.sys'@'localhost';
GRANT TRIGGER ON `sys`.* TO 'mysql.sys'@'localhost';
GRANT USAGE ON *.* TO 'mysql.sys'@'localhost';
-- Grants for 'nmcu'@'%'
CREATE USER IF NOT EXISTS 'nmcu'@'%';
ALTER USER 'nmcu'@'%' IDENTIFIED WITH 'mysql_native_password' AS '*706DABCD394065BC3EFF48210A5A134A483BCE3F' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK;
GRANT ALL PRIVILEGES ON `nmcu`.* TO 'nmcu'@'%';
GRANT USAGE ON *.* TO 'nmcu'@'%';
-- Grants for 'root'@'%'
CREATE USER IF NOT EXISTS 'root'@'%';
ALTER USER 'root'@'%' IDENTIFIED WITH 'mysql_native_password' AS '*706DABCD394065BC3EFF48210A5A134A483BCE3F' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK;
GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' WITH GRANT OPTION;
-- Grants for 'root'@'localhost'
CREATE USER IF NOT EXISTS 'root'@'localhost';
ALTER USER 'root'@'localhost' IDENTIFIED WITH 'mysql_native_password' AS '*706DABCD394065BC3EFF48210A5A134A483BCE3F' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK;
GRANT ALL PRIVILEGES ON *.* TO 'root'@'localhost' WITH GRANT OPTION;
GRANT PROXY ON ''@'' TO 'root'@'localhost' WITH GRANT OPTION;


CREATE DATABASE IF NOT EXISTS `nmcu`;

USE `nmcu`;

CREATE TABLE IF NOT EXISTS `actuators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(45) DEFAULT NULL,
  `model` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `boards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `firmwares` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `version` varchar(45) DEFAULT NULL,
  `file` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `measures_co2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_node` varchar(45) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `co2` varchar(45) DEFAULT NULL,
  `temperature` varchar(45) DEFAULT NULL,
  `humidity` varchar(45) DEFAULT NULL,
  `vcc` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=474325 DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `nodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `mac` varchar(45) DEFAULT NULL,
  `location` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `nodes_actuators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_node` int(11) DEFAULT NULL,
  `id_actuator` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `nodes_boards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_node` varchar(45) DEFAULT NULL,
  `id_board` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `nodes_firmware` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_node` int(11) DEFAULT NULL,
  `id_firmware` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `nodes_sensors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_node` int(11) DEFAULT NULL,
  `id_sensor` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `sensors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(45) DEFAULT NULL,
  `model` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

LOCK TABLES `actuators` WRITE;
/*!40000 ALTER TABLE `actuators` DISABLE KEYS */;
INSERT INTO `actuators` VALUES (1,'LED','RGB'),(2,'Screen','OLED 0.96\'');
/*!40000 ALTER TABLE `actuators` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `boards` WRITE;
/*!40000 ALTER TABLE `boards` DISABLE KEYS */;
INSERT INTO `boards` VALUES (1,'NodeMCU Amica');
/*!40000 ALTER TABLE `boards` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `firmwares` WRITE;
/*!40000 ALTER TABLE `firmwares` DISABLE KEYS */;
INSERT INTO `firmwares` VALUES (1,'co2_ar_cal','0.1','co2_ar_cal.bin');
/*!40000 ALTER TABLE `firmwares` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `nodes` WRITE;
/*!40000 ALTER TABLE `nodes` DISABLE KEYS */;
INSERT INTO `nodes` VALUES (1,'co2_node_1','68:C6:3A:87:C0:6A','ETSE');
/*!40000 ALTER TABLE `nodes` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `nodes_actuators` WRITE;
/*!40000 ALTER TABLE `nodes_actuators` DISABLE KEYS */;
INSERT INTO `nodes_actuators` VALUES (1,1,1),(2,1,2);
/*!40000 ALTER TABLE `nodes_actuators` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `nodes_boards` WRITE;
/*!40000 ALTER TABLE `nodes_boards` DISABLE KEYS */;
INSERT INTO `nodes_boards` VALUES (1,'1','1');
/*!40000 ALTER TABLE `nodes_boards` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `nodes_firmware` WRITE;
/*!40000 ALTER TABLE `nodes_firmware` DISABLE KEYS */;
INSERT INTO `nodes_firmware` VALUES (1,1,1);
/*!40000 ALTER TABLE `nodes_firmware` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `nodes_sensors` WRITE;
/*!40000 ALTER TABLE `nodes_sensors` DISABLE KEYS */;
INSERT INTO `nodes_sensors` VALUES (1,1,1),(2,1,2);
/*!40000 ALTER TABLE `nodes_sensors` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `sensors` WRITE;
/*!40000 ALTER TABLE `sensors` DISABLE KEYS */;
INSERT INTO `sensors` VALUES (1,'co2','MH-Z19'),(2,'temperature/humidity','DHT22');
/*!40000 ALTER TABLE `sensors` ENABLE KEYS */;
UNLOCK TABLES;
